SELECT DISTINCT dev.ename,
       dev1.employeeid
FROM devassignments dev1
INNER JOIN developer dev on dev.employeeid = dev1.employeeid
WHERE NOT EXISTS
        (SELECT employeeid
         FROM devassignments dev2
         WHERE EXISTS
                 (SELECT pname
                  FROM project proj
                  WHERE proj.ptype = 'external'
                      AND dev2.pname = proj.pname)
             AND dev1.employeeid = dev2.employeeid)
ORDER BY employeeid;
