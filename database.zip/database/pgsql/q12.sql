SELECT pname FROM devassignments GROUP BY pname HAVING COUNT(pname) <= 2 ORDER BY pname ;
