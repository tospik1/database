SELECT pname FROM devassignments WHERE employeeid=93401;
