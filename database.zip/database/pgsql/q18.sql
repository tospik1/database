SELECT pname, devcost

FROM

    (SELECT proj.pname,

            proj.budget/COUNT(devass.employeeid) AS devcost

     FROM project proj

     INNER JOIN devassignments devass on proj.pname = devass.pname

     GROUP BY proj.pname

    ) derived

WHERE devcost = (SELECT MAX(devcost)

FROM

    (SELECT proj1.pname,

            proj1.budget/COUNT(devass1.employeeid) AS devcost

     FROM project proj1

     INNER JOIN devassignments devass1 on proj1.pname = devass1.pname

     GROUP BY proj1.pname) temp)

ORDER BY pname;
