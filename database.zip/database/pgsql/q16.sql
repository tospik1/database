SELECT dev.ename,
       devass.employeeid
FROM devassignments devass
INNER JOIN developer dev ON devass.employeeid = dev.employeeid
WHERE devass.pname = 'Kodiak'
UNION
SELECT dev.ename,
       docauth.employeeid
FROM documentauthors docauth
INNER JOIN developer dev ON docauth.employeeid = dev.employeeid
WHERE EXISTS
        (SELECT doc.documentid
         FROM document doc
         WHERE doc.documentid = docauth.documentid
             AND doc.pname='Kodiak')
ORDER BY employeeid;
