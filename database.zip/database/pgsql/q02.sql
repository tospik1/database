SELECT developer.employeeid,ename FROM developer,documentauthors WHERE developer.employeeid = documentauthors.employeeid AND documentauthors.documentid = 22;
