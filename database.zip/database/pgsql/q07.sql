SELECT DISTINCT doc.pname,

       docauth.employeeid

FROM documentauthors docauth

INNER JOIN document doc on docauth.documentid = doc.documentid

WHERE NOT EXISTS

        (SELECT devass.pname,

                devass.employeeid

         FROM devassignments devass

         WHERE doc.pname = devass.pname

             AND docauth.employeeid = devass.employeeid)

ORDER BY doc.pname,

         docauth.employeeid;
