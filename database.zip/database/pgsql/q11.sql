SELECT pname FROM devassignments GROUP BY devassignments.pname HAVING COUNT(employeeid) > 2;
