SELECT devass.pname,
       devass.asgndate,
       p.ptype
FROM devassignments devass
INNER JOIN project proj ON devass.pname = proj.pname
WHERE devass.employeeid=82102
ORDER BY pname;
