SELECT COUNT(DISTINCT document.pname) AS numprojects
     FROM documentauthors docauth
     INNER JOIN document ON docauth.documentid = document.documentid
     WHERE docauth.employeeid=93401;
