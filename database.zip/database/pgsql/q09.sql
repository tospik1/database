SELECT COUNT(pstartdate) AS numprojects FROM project WHERE pstartdate> '2020-12-31';
