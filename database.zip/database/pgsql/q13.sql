SELECT proj.pname,
       COUNT(doc.documentid) AS numdocs
FROM project proj
LEFT JOIN document doc ON proj.pname = doc.pname
WHERE proj.ptype = 'internal'
GROUP BY proj.pname
ORDER BY numdocs DESC, proj.pname;
