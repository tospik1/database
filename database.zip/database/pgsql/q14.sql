SELECT pname, pstartdate FROM project where pstartdate=(select min(pstartdate) from project) ORDER BY pname;
