SELECT devassignments.employeeid,ename FROM devassignments LEFT JOIN developer ON devassignments.employeeid
= developer.employeeid WHERE pname = 'Kodiak' AND devassignments.employeeid NOT IN (SELECT documentauthors.employeeid FROM document LEFT JOIN documentauthors ON documentauthors.documentid=document.documentid WHERE document.pname =
'Kodiak');
